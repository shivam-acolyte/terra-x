import{j as s,F as e}from"./index-DY3fcFkZ.js";function o(){return s.jsx("div",{className:"pt-24",children:s.jsx(e,{})})}export{o as component};
