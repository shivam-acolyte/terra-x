import{j as s,S as t,a,C as e}from"./index-DY3fcFkZ.js";function r(){return s.jsxs("div",{className:"pt-24",children:[s.jsx(t,{}),s.jsx(a,{}),s.jsx(e,{})]})}export{r as component};
