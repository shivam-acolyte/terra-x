import{j as s,T as t,M as a}from"./index-DY3fcFkZ.js";function o(){return s.jsxs("div",{className:"pt-24",children:[s.jsx(t,{}),s.jsx(a,{})]})}export{o as component};
