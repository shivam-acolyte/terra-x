import{j as s,A as o,F as t}from"./index-DY3fcFkZ.js";function n(){return s.jsxs("div",{className:"pt-24",children:[s.jsx(o,{}),s.jsx(t,{})]})}export{n as component};
