import{j as t,d as s}from"./index-DY3fcFkZ.js";function o(){return t.jsx("div",{className:"pt-24",children:t.jsx(s,{})})}export{o as component};
