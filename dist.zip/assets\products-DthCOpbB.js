import{j as s,P as o,H as t}from"./index-DY3fcFkZ.js";function a(){return s.jsxs("div",{className:"pt-24",children:[s.jsx(o,{}),s.jsx(t,{})]})}export{a as component};
