import{j as s,b as e,c as t,B as a}from"./index-DY3fcFkZ.js";function n(){return s.jsxs("div",{className:"pt-24",children:[s.jsx(e,{}),s.jsx(t,{}),s.jsx(a,{})]})}export{n as component};
